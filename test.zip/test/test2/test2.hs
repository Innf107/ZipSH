test x = x + 1

f x = x * x

h x y = x + y
g x = x + x 
